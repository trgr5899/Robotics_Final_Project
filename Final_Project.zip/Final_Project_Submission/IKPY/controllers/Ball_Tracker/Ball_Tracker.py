import sys
import tempfile
import ikpy
from ikpy.chain import Chain
import math
from controller import Supervisor

supervisor = Supervisor()
timeStep = int(4 * supervisor.getBasicTimeStep())

Chain = Chain.from_urdf_file("TiagoSteel.urdf", base_elements = ["base_link", "base_link_Torso_joint", 
"Torso", "torso_lift_joint", "torso_lift_link", 
"torso_lift_link_TIAGo front arm_21067_joint", "TIAGo front arm_21067"], active_links_mask = [True,
False, False, False, True, True, True, True, True, True, True, False, False, False])

print(Chain)

target = supervisor.getFromDef('TARGET')
tiago = supervisor.getSelf()

while supervisor.step(timeStep) != -1:
    targetPosition = target.getPosition()
    tiagoPosition = tiago.getPosition()
    
    x = targetPosition[0] - tiagoPosition[0]
    y = - (targetPosition[2] - tiagoPosition[2])
    z = targetPosition[1] - tiagoPosition[1]
    
    #print("The angles of each joints are : ", Chain.inverse_kinematics([x,y,z]))
    #print(len(Chain))
    cord = Chain.inverse_kinematics([x,y,z])
    #print(cord)
    
    i = 0
    for link in Chain.links:
        #print(cord[i])
        #print(i)
        if(cord[i] != 0):
            arm = supervisor.getDevice(link.name)
            arm.setPosition(cord[i])
            #print("here")
        i = i + 1