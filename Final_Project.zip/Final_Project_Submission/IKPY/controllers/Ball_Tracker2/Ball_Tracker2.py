import sys
import tempfile
import ikpy
from ikpy.chain import Chain
from ikpy.urdf.URDF import get_chain_from_joints
# from ikpy.urdf.utils import get_urdf_tree
import math
from controller import Supervisor

supervisor = Supervisor()
timeStep = int(4 * supervisor.getBasicTimeStep())

part_names = ("torso_lift_joint", "arm_1_joint", 
              "arm_2_joint", "arm_3_joint",  
              "arm_4_joint", "arm_5_joint",
              "arm_6_joint",  "arm_7_joint", 
              "gripper_right_finger_joint", "gripper_left_finger_joint")

target_positions = (0.15, 0.07, 0, 0, 0, 0, 0, 0, 0, 0)
robot_parts = []
for i in range(len(part_names)):
    robot_parts.append(supervisor.getDevice(part_names[i]))
    robot_parts[i].setPosition(float(target_positions[i]))
    robot_parts[i].setVelocity(robot_parts[i].getMaxVelocity() / 1.0)

Chain = Chain.from_urdf_file("TiagoSteel.urdf", base_elements = ["base_link", "base_link_Torso_joint", 
"Torso", "torso_lift_joint", "torso_lift_link", 
"torso_lift_link_TIAGo front arm_21067_joint", "TIAGo front arm_21067"], active_links_mask = [False, False, False, False, True, True, True, True, True, True, True, False, False, False])

# chain_elements = get_chain_from_joints("TiagoSteel.urdf", ["base_link_Torso_joint", "torso_lift_joint", "torso_lift_link_TIAGo front arm_21067_joint", 
# "arm_1_joint", "arm_2_joint", "arm_3_joint", "arm_4_joint", 
# "arm_5_joint", "arm_6_joint", "arm_7_joint"])
# print(chain_elements)

# get_urdf_tree("TiagoSteel.urdf")

# Chain = Chain.from_urdf_file("TiagoSteel.urdf", base_elements = chain_elements)
# Chain.active_links_mask[0] = False # Making the base link inactive
# print(Chain)

target = supervisor.getFromDef('TARGET')
tiago = supervisor.getSelf()


while supervisor.step(timeStep) != -1:
    targetPosition = target.getPosition()
    tiagoPosition = tiago.getPosition()
            
    x = targetPosition[0]
    y = -targetPosition[2]
    z = targetPosition[1]
            
            #print("The angles of each joints are : ", Chain.inverse_kinematics([x,y,z]))
            #print(len(Chain))
    cord = Chain.inverse_kinematics([x,y,z])
    real_frame = Chain.forward_kinematics(cord)
            #print("End-effector pose after setting the joint angles:", real_frame[:3, 3])
    target_positions = [cord[2], cord[4], cord[5], cord[6], cord[7], cord[8], cord[9], cord[10], 0, 0]
            # print(cord)
    for i in range(len(part_names)):
        robot_parts[i].setPosition(float(target_positions[i]))
            
            # Use this to open the gripper and a slightl smaller number to close it. 
    robot_parts[-1].setPosition(0.045)
    robot_parts[-2].setPosition(0.045)
        
    
    
                
            # for i in range(len(part_names)):
                # print(robot_parts[i].getPosition(float(target_positions[i])))
            # i = 0
            
            # for link in Chain.links:
                
                # #print(cord[i])
                # #print(i)
                # if(cord[i] != 0):
                    # arm = supervisor.getDevice(link.name)
                    # if arm is not None:
                        # print(type(link.name))
                        # print(link.name)
                        # print(arm)
                        # arm.setPosition(cord[i])
                    # #print("here")
                # i = i + 1