import sys
import tempfile
import ikpy
from ikpy.chain import Chain
from ikpy.urdf.URDF import get_chain_from_joints
# from ikpy.urdf.utils import get_urdf_tree
import math
from controller import Supervisor

supervisor = Supervisor()
timeStep = int(4 * supervisor.getBasicTimeStep())

my_chain = Chain.from_urdf_file("TiagoSteel.urdf", last_link_vector=[0.004, 0,-0.1741], base_elements=["base_link", "base_link_Torso_joint", "Torso", "torso_lift_joint", "torso_lift_link", "torso_lift_link_TIAGo front arm_21067_joint", "TIAGo front arm_21067"])
#print(my_chain.links)

part_names = ("head_2_joint", "head_1_joint", "torso_lift_joint", "arm_1_joint",
            "arm_2_joint",  "arm_3_joint",  "arm_4_joint",      "arm_5_joint",
            "arm_6_joint",  "arm_7_joint",  "wheel_left_joint", "wheel_right_joint")

for link_id in range(len(my_chain.links)):

    # This is the actual link object
    link = my_chain.links[link_id]
    
    # I've disabled "torso_lift_joint" manually as it can cause
    # the TIAGO to become unstable.
    if link.name not in part_names or  link.name =="torso_lift_joint":
        print("Disabling {}".format(link.name))
        my_chain.active_links_mask[link_id] = False
# Initialize the arm motors and encoders.
motors = []
for link in my_chain.links:
    if link.name in part_names and link.name != "torso_lift_joint":
        motor = supervisor.getDevice(link.name)

        # Make sure to account for any motors that
        # require a different maximum velocity!
        if link.name == "torso_lift_joint":
            motor.setVelocity(0.07)
        else:
            motor.setVelocity(1)
            
        position_sensor = motor.getPositionSensor()
        position_sensor.enable(timeStep)
        motors.append(motor)
        
initial_position = [0,0,0,0] + [m.getPositionSensor().getValue() for m in motors] + [0,0,0,0]

target = supervisor.getFromDef('TARGET')
targetPosition = target.getPosition()

offset_target = [targetPosition[0]+0.08, (targetPosition[2])+0.22, -(targetPosition[1])+0.97+0.2]

ikResults = my_chain.inverse_kinematics(offset_target, initial_position=initial_position,  target_orientation = [0,0,1], orientation_mode="Y")

for res in range(len(ikResults)):
    # This if check will ignore anything that isn't controllable
    if my_chain.links[res].name in part_names:
        supervisor.getDevice(my_chain.links[res].name).setPosition(ikResults[res])
        print("Setting {} to {}".format(my_chain.links[res].name, ikResults[res]))