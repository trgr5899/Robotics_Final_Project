//Jack's robot arm
#include <webots/motor.h>
#include <webots/robot.h>
#include <stdlib.h>
#include <stdio.h>
#define MOTOR_NUMBER 8

static WbDeviceTag motors[MOTOR_NUMBER];

static const char *motor_names[MOTOR_NUMBER] = {"1", "2", "3", "4", "5", "6", "7", "7 left"};

static int get_time_step() {
  static int time_step = -1;
  if (time_step == -1)
    time_step = (int)wb_robot_get_basic_time_step();
  return time_step;
}

static void step() {
  if (wb_robot_step(get_time_step()) == -1) {
    wb_robot_cleanup();
    exit(EXIT_SUCCESS);
  }
}

static void passive_wait(double sec) {
  double start_time = wb_robot_get_time();
  do {
    step();
  } while (start_time + sec > wb_robot_get_time());
}

void open_gripper() {
  wb_motor_set_position(motors[6], 0.3);
  wb_motor_set_position(motors[7], 0.3);
}

void close_gripper() {
  //wb_motor_set_torque(motors[6], -0.2);
  //wb_motor_set_torque(motors[7], -0.2);
  wb_motor_set_position(motors[6], 0.025);
  wb_motor_set_position(motors[7], 0.025);
}


int ball=0;
int main(int argc, char **argv) {
  wb_robot_init();

  for (int i = 0; i < MOTOR_NUMBER; ++i)
    motors[i] = wb_robot_get_device(motor_names[i]);

  while (true) {
  
    //Put the robot in the intial position to throw the ball
    if (ball==0)
    {
      wb_motor_set_position(motors[0], -1.55);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(1);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(0.5);
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      // prepare for grasping the ball
      open_gripper();
      passive_wait(0.75);
      
      // grab the ball
      close_gripper();
      passive_wait(3.0);
  
      wb_motor_set_position(motors[2], 0);
      passive_wait(3.0);
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], 2.95903);
      
      passive_wait(2);
      //wb_motor_get_max_force(motors[1]));
      wb_motor_set_position(motors[2], -0.52);

      passive_wait(2);
      
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(10);
      ball=ball+1;
     }
     else if(ball==1)
     {
      open_gripper();
      wb_motor_set_position(motors[0], 2.95903);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(3);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(3);
      close_gripper();
      passive_wait(1);
      wb_motor_set_position(motors[2], 0);
      passive_wait(3.0);
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], 1.0);
      
      passive_wait(5);
      //wb_motor_get_max_force(motors[1]));
      wb_motor_set_position(motors[2], -0.528);
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      passive_wait(2);
      
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);

      
      ball=ball+1;
     }
     else if(ball==2)
     {
      passive_wait(2);
      open_gripper();
      wb_motor_set_position(motors[0], -2);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(3);
      close_gripper();
      passive_wait(1);
      wb_motor_set_position(motors[2], 0);
      passive_wait(3.0);
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], 1.88);
      
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.4);
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      passive_wait(2);
      
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);
      
      ball=ball+1;
     }
     else
     {
       break;
     }
    
  };

  wb_robot_cleanup();

  return 0;
}
