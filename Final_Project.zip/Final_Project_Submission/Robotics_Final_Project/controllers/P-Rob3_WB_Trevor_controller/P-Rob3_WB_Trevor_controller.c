
//Necessary libraries to include
//Trevor Green's P-rob3(white/blue) arm controller
//This arm throws various different balls and throws the yellow ball that Tiago is supposed to find
//It has functionallity to throw balls randomly and to manually choose the angle to throw the yellow ball

#include <webots/motor.h>
#include <webots/robot.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <webots/keyboard.h>
#define MOTOR_NUMBER 8
#define TIME_STEP 10

//This puts all of the 8 motors for p-rob3 in an array
static WbDeviceTag motors[MOTOR_NUMBER];
static const char *motor_names[MOTOR_NUMBER] = {"1", "2", "3", "4", "5", "6", "7", "7 left"};

//most of these function are based of of ones from the orginal p-rob3 controller
//this gets the current time step which will be used within the next few functions
static int get_time_step() {
  static int time_step = -1;
  if (time_step == -1)
    time_step = (int)wb_robot_get_basic_time_step();
  return time_step;
}

//this function just goes through one time step
static void step() {
  if (wb_robot_step(get_time_step()) == -1) {
    wb_robot_cleanup();
    exit(EXIT_SUCCESS);
  }
}

//THis function takes in a number and seconds and then performs a passive wait
//for the set amount of time
static void passive_wait(double sec) {
  double start_time = wb_robot_get_time();
  do {
    step();
  } while (start_time + sec > wb_robot_get_time());
}

//This opens the grippers
void open_gripper() {
  wb_motor_set_position(motors[6], 0.3);
  wb_motor_set_position(motors[7], 0.3);
}

//this closses the gripper
void close_gripper() {
  wb_motor_set_position(motors[6], 0.025);
  wb_motor_set_position(motors[7], 0.025);
}

/*
I added this function to allow for manual controls of the p-rob3 arm
if the user wants to manually choose the angle to throw the ball.
This was not used within our final project but I thought that it would 
be a cool functionality to add to my arm. 

How to put into manual mode to throw the yellow ball:
1.) uncomment lines 135 and 247
2.) rebuild the C file
*/

void control_angle_to_throw_yellow_ball()
{
  int num = 0;
  float current_motor_position=0.0;
  bool run=true;
  printf("Click Right arrow to Rotate Clockwise by 0.15 radians\n");
  printf("Click Left arrow to Rotate Counter Clockwise by 0.15 radians\n");
  printf("Click Down arrow if you have the arm throwing at the desired angle\n");
        while (run) {
          step();
      
          int c = wb_keyboard_get_key();
          if ((c >= 0) && c != num) {
            switch (c) {
              case WB_KEYBOARD_RIGHT:
                printf("Rotate Clockwise\n");
                current_motor_position=wb_motor_get_target_position(motors[0]);
                if ((current_motor_position+0.15) > 2.95)
                {
                  printf("Rotating to correct position please wait\n");
                  current_motor_position=((current_motor_position+0.15)-2.95)-2.95;
                }
                else
                {
                  current_motor_position=current_motor_position+0.15;
                }
                wb_motor_set_position(motors[0], current_motor_position);
                break;
              case WB_KEYBOARD_LEFT:
                printf("Rotate Counter Clockwise \n");
                current_motor_position=wb_motor_get_target_position(motors[0]);
                if ((current_motor_position-0.15) < -2.95)
                {
                  printf("Rotating to correct position please wait\n");
                  current_motor_position=((current_motor_position-0.15)+2.95)+2.95;
                }
                else
                {
                  current_motor_position=current_motor_position-0.15;
                }
                wb_motor_set_position(motors[0], current_motor_position);
                break;
              case WB_KEYBOARD_DOWN:
                printf("Exiting Manual Mode\n");
                run=false;
                break;
              default:
                fprintf(stderr, "Wrong keyboard input\n");
                break;
            }
          }
          num = c;
        }
}

//Since this is written in c, the main runs the entire program

//
//MAIN function
//
int main(int argc, char **argv) {
  //This initializes the robot

  wb_robot_init();
  
  //**uncomment the line below to use manual mode**
  //wb_keyboard_enable(TIME_STEP);
  
  //Puts all of the motors into the motors array
  for (int i = 0; i < MOTOR_NUMBER; ++i)
    motors[i] = wb_robot_get_device(motor_names[i]);
    
  //this will increment for which ball we are going to throw
  int ball=0;
  
  //This code is meant to give the arm a random angle for the motor[0] to throw the ball so that it is more difficult
  // for the tiago steel to find the correct ball to pick up
  //I used this functionallity for the simulation of our project but as you read above
  //I also added a manual mode
  srand((unsigned int)time(NULL));
  float a = 2.95;
  static float random_angles[20];
  for (int i=0;i<20;i++)
  {
    random_angles[i]=(((float)rand()/(float)(RAND_MAX)) * a);
    
  }
  
  
  while (true) {
    
    //This is the case for throwing the first ball
    if (ball==0)
    {
      
      
      //Sets the initial position for the motors to pick up the first ball
      wb_motor_set_position(motors[0], -1.55);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(0.5);
      //Set the force of the grippers so that maximum force is applied to grab the ball
      //this makes sure that the ball is not dropped
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      
      //open the gripper
      open_gripper();
      passive_wait(0.75);
      
      // grab the ball
      close_gripper();
      passive_wait(3.0);
      
      //Lift the ball off of the ground
      wb_motor_set_position(motors[2], 0);
      passive_wait(1.0);
      
      //slow down the motor so that the ball is not dropped then move the bottom motor into a random angle
      //to throw the ball
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], random_angles[5]);
      
      passive_wait(5);
      
      //Throwing the ball 
      
      wb_motor_set_position(motors[2], -0.4);
      passive_wait(2);
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);
      
      //increment to the next ball to be thrown
      ball=ball+1;
     }
     else if(ball==1)
     {
      //Sets the initial position for the motors to pick up the second ball
      wb_motor_set_position(motors[0], 0);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(1);
      //Set the force of the grippers so that maximum force is applied to grab the ball
      //this makes sure that the ball is not dropped
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      
      //open the gripper
      open_gripper();
      passive_wait(0.75);
      
      // grab the ball
      close_gripper();
      passive_wait(3.0);
      
      //Lift the ball off of the ground
      wb_motor_set_position(motors[2], 0);
      passive_wait(1.0);
      //slow down the motor so that the ball is not dropped then move the bottom motor into a random angle
      //to throw the ball
      wb_motor_set_velocity(motors[0],0.6);
      
      /*
      Right here you can choose to have the yellow ball be thrown at a random angle
      or you can manually controll the angle 
      all you have to do is uncomment the option you want to use
      */
      
      //random
      wb_motor_set_position(motors[0], random_angles[9]);
      
      //**uncomment line below to run manual mode to choose angle of yellow ball**
      //control_angle_to_throw_yellow_ball();
      passive_wait(5);
      
      //Throwing the ball 
      
      wb_motor_set_position(motors[2], -0.4);
      passive_wait(2);
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);
      
      //increment to the next ball to be thrown
      ball=ball+1;
     }
     else if(ball==2)
     {
      //Sets the initial position for the motors to pick up the third ball
      wb_motor_set_position(motors[0], -0.75);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(1);
      
      //Set the force of the grippers so that maximum force is applied to grab the ball
      //this makes sure that the ball is not dropped
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      
      //open the gripper
      open_gripper();
      passive_wait(0.75);
      
      // grab the ball
      close_gripper();
      passive_wait(3.0);
      
      //Lift the ball off of the ground
      wb_motor_set_position(motors[2], 0);
      passive_wait(1.0);
      
      //slow down the motor so that the ball is not dropped then move the bottom motor into a random angle
      //to throw the ball
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], random_angles[15]);
      
      passive_wait(5);
      
      //Throwing the ball 
      
      wb_motor_set_position(motors[2], -0.4);
      passive_wait(2);
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);
      
      //increment to the next ball to be thrown
      ball=ball+1;
     }
     else if(ball==3)
     {
    
      //Sets the initial position for the motors to pick up the 4th  ball
      wb_motor_set_position(motors[0], 0.75);
      wb_motor_set_position(motors[1], -1.55);
      passive_wait(5);
      wb_motor_set_position(motors[2], -0.52);
      passive_wait(1);
      //Set the force of the grippers so that maximum force is applied to grab the ball
      //this makes sure that the ball is not dropped
      wb_motor_set_available_force(motors[6], wb_motor_get_max_force(motors[6]));
      wb_motor_set_available_force(motors[7], wb_motor_get_max_force(motors[7]));
      
      //open the gripper
      open_gripper();
      passive_wait(0.75);
      
      // grab the ball
      close_gripper();
      passive_wait(3.0);
      
      //Lift the ball off of the ground
      wb_motor_set_position(motors[2], 0);
      passive_wait(1.0);
      
      //slow down the motor so that the ball is not dropped then move the bottom motor into a random angle
      //to throw the ball
      wb_motor_set_velocity(motors[0],0.6);
      wb_motor_set_position(motors[0], random_angles[0]);
      
      passive_wait(5);
      
      //Throwing the ball 
      
      wb_motor_set_position(motors[2], -0.4);
      passive_wait(2);
      wb_motor_set_velocity(motors[1],1.745);
      wb_motor_set_position(motors[1], 1.55);
      wb_motor_set_position(motors[2], 1.5);
      passive_wait(0.8);
      open_gripper();
      passive_wait(3);
      
      wb_motor_set_position(motors[0], 0);
      wb_motor_set_position(motors[1], 0);
      wb_motor_set_position(motors[2], 0);
      //increment to the next ball to be thrown
      ball=ball+1;
     }
     else{
       //This ends the code
       break;
     }
    
  };

  wb_robot_cleanup();

  return 0;
  }