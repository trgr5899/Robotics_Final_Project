"""Tiago Steel controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Supervisor, Motor, Camera, CameraRecognitionObject, GPS
import math
import sys
import tempfile
import ikpy
from ikpy.chain import Chain
# create the Robot instance.
robot = Supervisor()
camera = Camera("camera")
# get the time step of the current world.
timestep = timeStep = int(4 * robot.getBasicTimeStep())
camera.enable(timestep)
camera.recognitionEnable(timestep)

gps = robot.getDevice("gps")
gps.enable(timestep)
lidar = robot.getDevice('Hokuyo URG-04LX-UG01')
lidar.enable(timestep)
lidar.enablePointCloud()

Chain = Chain.from_urdf_file("TiagoSteel.urdf", base_elements = ["base_link", "base_link_Torso_joint", 
"Torso", "torso_lift_joint", "torso_lift_link", 
"torso_lift_link_TIAGo front arm_21067_joint", "TIAGo front arm_21067"], active_links_mask = [False, False, False, False, True, True, True, True, True, True, True, False, False, False])

print()
MAX_SPEED = 7.0  # [rad/s]
MAX_SPEED_MS = 0.5725 # [m/s]
AXLE_LENGTH = 0.4044 # m
MOTOR_LEFT = 10 # Left wheel index
MOTOR_RIGHT = 11 # Right wheel index
N_PARTS = 12 # Total joints

part_names = ("head_2_joint", "head_1_joint", "torso_lift_joint", "arm_1_joint",
              "arm_2_joint",  "arm_3_joint",  "arm_4_joint",      "arm_5_joint",
              "arm_6_joint",  "arm_7_joint",  "wheel_left_joint", "wheel_right_joint")


target_pos = (0.0, 0.0, 0.09, 0.07, 0.26, -3.16, 1.27, 1.32, 0.00, 1.41, "inf", "inf")
robot_parts = []

for i in range(N_PARTS):
        robot_parts.append(robot.getDevice(part_names[i]))
        robot_parts[i].setPosition(float(target_pos[i]))
        robot_parts[i].setVelocity(robot_parts[i].getMaxVelocity() / 2.0)


# Main loop:
# - perform simulation steps until Webots is stopping the controller
#middle_x = -0.95
#middle_y = -0.83
next_goal = [0,0]
middle = False
loc = gps.getValues()
pose_theta = 0
pose_x = 1.79
pose_y = 2.95
first = True
object_found = False
obj = [0,0,0]
index = 0
count = 0
while robot.step(timestep) != -1:
   
    if count < 1000:
        count += 1
        vL = 0
        vR = 0
    else:
        if (camera.getRecognitionNumberOfObjects() > 0 and not object_found):
            for i in range(camera.getRecognitionNumberOfObjects()):
                print("Object Id:",camera.getRecognitionObjects()[i].get_id())
                if (camera.getRecognitionObjects()[i].get_id() == 22629):
                    object_found = True
                    index = i
                    object = camera.getRecognitionObjects()[index]
                    obj = object.get_position()
                    o = object.get_orientation()
        if (not object_found):
            vL = 0.1*MAX_SPEED
            vR = -0.1*MAX_SPEED
        else:
            loc = gps.getValues()
            if (camera.getRecognitionNumberOfObjects() > 0 and first and object_found):
                first_x = loc[0]
                first_y = loc[2]
                first = False
            if(object_found):
                xbxo = math.cos(pose_theta)
                target = robot.getFromDef('TARGET')
                targetPosition = target.getPosition()
               
                next_goal = [targetPosition[0], targetPosition[2]]
                
                pos_error = math.sqrt(((next_goal[0] - pose_x)**2) + ((next_goal[1] - pose_y)**2))
                angle_error = pose_theta - math.atan2(next_goal[1] - pose_y,next_goal[0] - pose_x)
                
                if (angle_error < -math.pi):
                    angle_error = angle_error + (2*math.pi)
                    
                x_r = pos_error
                theta_r = 2 * angle_error
                
                vL = (2*x_r - theta_r*AXLE_LENGTH)/ 2.0
                vR = (2*x_r + theta_r*AXLE_LENGTH)/ 2.0
                
                ratio = vL/vR
                if(vL > MAX_SPEED and vR > MAX_SPEED):
                    if(ratio > 1):
                        vR = MAX_SPEED / ratio
                        vL = MAX_SPEED
                    else:
                        vL = MAX_SPEED * ratio
                        vR = MAX_SPEED
                        
                if(vL < -MAX_SPEED and vR < -MAX_SPEED):
                    if(ratio > 1):
                        vR = -MAX_SPEED / ratio
                        vL = -MAX_SPEED
                    else:
                        vL = -MAX_SPEED * ratio
                        vR = -MAX_SPEED
                
                if (vL > MAX_SPEED):
                    vL = MAX_SPEED
                if (vR > MAX_SPEED):
                    vR = MAX_SPEED
                if (vL < -MAX_SPEED):
                    vL = -MAX_SPEED
                if (vR < -MAX_SPEED):
                    vR = -MAX_SPEED 
          
        pose_x = gps.getValues()[0]
        pose_y = gps.getValues()[2]
        pose_theta += (vL-vR)/AXLE_LENGTH/MAX_SPEED*MAX_SPEED_MS*timestep/1000.0
        if pose_theta > math.pi:
            pose_theta = pose_theta - 2*math.pi
        if pose_theta < -math.pi:
            pose_theta = pose_theta + 2*math.pi
            
        if ((((abs(next_goal[0]) - abs(pose_x)) < 0.3) and ((abs(next_goal[0]) - abs(pose_x)) > -0.3)) and (((abs(next_goal[1]) - abs(pose_y)) < 0.3)) and ((abs(next_goal[1]) - abs(pose_y)) > -0.3)):
            vL = 0
            vR = 0
            #
            # This was the inverse kinematics but does not work, look at IKPY world for inverse kinematics 
            #
            #part_name = ("torso_lift_joint", "arm_1_joint", 
            #  "arm_2_joint", "arm_3_joint",  
            #  "arm_4_joint", "arm_5_joint",
            #  "arm_6_joint",  "arm_7_joint", 
            #  "gripper_right_finger_joint", "gripper_left_finger_joint")

            #target_positions = (0.15, 0.07, 0, 0, 0, 0, 0, 0, 0, 0)
            #robot_part = []
            #for i in range(len(part_name)):
            #    robot_part.append(robot.getDevice(part_name[i]))
            #    robot_part[i].setPosition(float(target_positions[i]))
            #    robot_part[i].setVelocity(robot_part[i].getMaxVelocity() / 1.0)
            
            #target = robot.getFromDef('TARGET')
            #tiago = robot.getSelf()
            
            #targetPosition = target.getPosition()
            #tiagoPosition = tiago.getPosition()
    
            #x = targetPosition[0] 
            #y = -targetPosition[2] 
            #z = targetPosition[1]
            
            #cord = Chain.inverse_kinematics([x,y,z])
            #real_frame = Chain.forward_kinematics(cord)
            #print("End-effector pose after setting the joint angles:", real_frame[:3, 3])
            #target_positions = [cord[2], cord[4], cord[5], cord[6], cord[7], cord[8], cord[9], cord[10], 0, 0]
            # print(cord)
            #for i in range(len(part_name)):
            #    robot_part[i].setPosition(float(target_positions[i]))
            
            # Use this to open the gripper and a slightl smaller number to close it. 
            #robot_parts[-1].setPosition(0.045)
            #robot_parts[-2].setPosition(0.045)
               
    robot_parts[MOTOR_LEFT].setVelocity(vL)
    robot_parts[MOTOR_RIGHT].setVelocity(vR)